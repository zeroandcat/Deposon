# Deposon Paper — arXiv Source Package (English Version, Fixed Update)

**Project version**: deposon v0.1.1
**Date**: 2026-09-08
**arXiv category**: cs.AI
**Repository**: https://github.com/zeroandcat/Deposon
**Author**: Qihao Yuan (single author), School of Chemistry and Life Resources, Renmin University of China

This is the **English-only** source package, split from the 2026-09-08 delivery. This is the same-day **fixed update (round 3)**: all 8 classes of known carried-over issues listed in the first split-package README, plus two visibility defects that only surfaced once the file compiled end-to-end, were fixed with a **0-error tectonic build**; round 2 additionally fixes the double section numbering, the residual Overfull boxes, and missing font shapes, and re-verifies with **0 errors / 0 Overfull**; round 3 additionally makes all fonts resolvable in arXiv's pristine TeX Live environment (a fandol-first CJK fallback chain via `IfFontExistsTF`) and moves the Data / Artifact availability statements into footnotes (see the fix record below); round 4 (user instructions at 15:38/15:43/15:48) promotes the Data / Artifact availability statements and the AI declaration (project version and author declaration, incl. acknowledgments) to standalone body sections after the Conclusion, wording moved byte-for-byte. The original mixed package and the first split package are retained for reference. A separate Chinese-only package `deposon_arxiv_2026_cn.tar.gz` (also the round-4 fixed update) exists with the same structure.

## Contents

- `deposon_paper_en.tex` — English paper, fixed (main submission to arXiv cs.AI)
- `references.bib` — BibTeX bibliography (62 entries). The tex builds with an inline `thebibliography`, so BibTeX is NOT required; the `.bib` is provided for downstream reuse.
- `figures/` — 5 English figure PNGs, numbered by order of first appearance (Figures 1–5): `fig1_ecr_distribution_en.png`, `fig2_boundary_map_en.png`, `fig3_killsign_scatter_en.png`, `fig4_division_scatter_en.png`, `fig5_gt7_frontier_en.png`. Figure content is unchanged; filenames follow the renumbered captions.
- No build products are included in the package (the compiled verification PDF is attached alongside the group message, not inside the archive).

## Compilation (English version)

**`xelatex` is the engine of record** (Unicode text-mode symbols: ★ ∞ − × ≫, superscripts such as ⁻¹⁶, Greek letters):

```bash
xelatex deposon_paper_en.tex
xelatex deposon_paper_en.tex   # run twice for stable cross-references
# or (the command used for the verified build, tectonic 0.15.0, networked):
tectonic deposon_paper_en.tex
```

Engine notes:
- The preamble now uses a **font fallback chain that requires no locally installed system fonts**: `\IfFontExistsTF{DejaVu Serif}` (DejaVu ships inside TeX Live; falls back to Latin Modern, also bundled, if absent) with `AutoFakeSlant=0.25`; ★ (U+2605) / ≫ (U+226B) render via DejaVu Sans, falling back to `\bigstar` / `\gg` (amssymb) if absent — measured 0 missing-glyph warnings.
- **arXiv-server compatibility (the round-3 core)**: every font referenced resolves inside a stock TeX Live distribution (dejavu / lmodern / amsfonts; the Chinese package additionally uses fandol), so arXiv's pristine TeX environment compiles this source with no system-font dependency; arXiv's build system auto-selects the XeLaTeX engine from the fontspec dependency signature.
- **Verified result (2026-09-08, round 3, re-verified after the font-chain upgrade)**: 0 errors, 0 Overfull boxes, 24-page PDF; 0 missing glyphs; the compile log confirms DejaVu Serif + DejaVu Sans resolved from the TeX Live bundle.
- `pdflatex` is not supported by this source as-is.

## Fix record (2026-09-08: all known issues fixed and compile-verified)

Fix principle: **frozen numbers and verdict wording untouched**. Apart from restoring the `τ*`, field-path wildcards `*`, and the interval `[0,4]` that the markdown→LaTeX conversion had eaten, no textual content was changed; typesetting fixes only add or remove layout commands, never visible characters. All 18 frozen numeric anchors (audit residual 2.220446049250313, P1a max‖T−BR‖∞=0.8569, ECR median=1.333, GSM8K 85.0 vs CoT 97.0, seed=210021, the five pre-registered SHA-256 first-12-hex anchors, etc.) were counted item-by-item, identical before and after the fix.

**In total: 12 classes, 32 fixes** — the 8 classes (16 spots) from the first-delivery README checklist, 1 glyph-rendering class, and 3 classes (15 spots) of visibility fixes added after the full compile.

### 1. First-delivery README checklist, item by item (8 classes, 16 spots; line numbers refer to the first delivery)

1. **L144 / L154, figure captions (fixed)**: `\\_` double escapes changed to `\_`, removing the "Missing $ inserted" hard error (the actual first halt point of the as-is file).
2. **Citation corruption, ×3 (fixed)**: `τ∈\cite{key00,key04}` restored to `τ∈[0,4]`.
3. **τ\* eaten, ×4 (fixed)**: `τ*` restored; stray `\textit{ }` spans removed.
4. **Wildcards eaten, ×2 (fixed)**: the `*`s in `per_T.*.per_domain.*.accuracy`, `per_domain.*.named_summary`, `backend.*` restored.
5. **Appendix-table pipes, ×1 (fixed)**: `Wilcoxon p=0.0031, |r|=0.83; paired t p<0.0001/d=2.05` merged into a single cell, removing the "Extra alignment tab" hard error.
6. **abstract structure, ×1 (fixed)**: `\end{abstract}` moved to right after the keywords; the body is typeset normally.
7. **Bare footnote + stray `---`, ×2 (fixed)**: the unattachable bare `\footnote` after `\end{abstract}` (duplicate of the closing "¹ Project version and author declaration" paragraph) and the stray rule were removed.
8. **Preamble fontspec, ×1 (fixed)**: `fontspec` + DejaVu Serif (+ newunicodechar glyph mapping) added.

### 2. Glyph rendering (1 class)

★ (U+2605) and ≫ (U+226B) are not in DejaVu Serif (they rendered as blanks in the first build); a `newunicodechar` mapping now renders them via DejaVu Sans, matching the symbols inside the figures. Zero textual change; measured 0 missing-glyph warnings.

### 3. Visibility fixes added after the full compile (3 classes, 15 spots)

These only became observable once the file compiled past its first halt point; per-page character-coordinate measurement (pdfplumber) confirmed content clipped past the right page edge:

1. **Appendix number-anchor table, whole column off-page (1 spot)**: the original `tabular{ll}` was far too wide — its entire second column (field paths) ran past the page edge (measured 3,060 invisible characters). Converted to `\footnotesize` + `longtable{p{0.50\textwidth}p{0.42\textwidth}}` with the header repeated across pages via `\endhead`; cell contents byte-identical.
2. **Global line-breaking parameter (1 spot)**: `\emergencystretch=2em` added to the preamble (the standard third-pass mechanism for long `\texttt` paths that TeX would otherwise typeset overfull at default tolerance).
3. **Long-token breakpoints (12+2 spots)**: 12 in-table field-path tokens of ≥40 characters, plus 2 body instances (the `deposon_benchmark_v1_3_traps.json → variant_results.{…}` chunk and `deposon_benchmark_v1_3_labelshuffle.json`), received `\allowbreak` at natural boundaries (`.`, `,`, `→`, `_`) — pure break permission, zero visible characters added or removed. Clipped body characters: 20 before (16+4), 0 after.

**Residuals after the fix**: the 8 first-round Overfull boxes were eliminated in round 2 (see §4 below); 112 Underfull lines remain as in-page looseness notes after the relaxed line-breaking tolerance; no missing glyphs; no off-page characters.

**Frozen-number verification**: byte-level diff review of the fixed vs first-delivery tex — every change is a layout command or a restoration of eaten characters (`τ*`, `*`, `[0,4]`); the 18 frozen anchors match item-by-item.

### 4. Round-2 fixes (2026-09-08 evening: numbering unified, Overfull eliminated, font shapes completed; user-feedback re-audit)

Following the user's feedback on the verification PDF (double section numbering; some fields running past the page), plus a full re-audit. **Zero changes to body text, numbers, or verdict wording** (diff re-checked: changes touch only heading commands and 4 preamble layout lines):

1. **Double section numbering (16 heading commands)**: the source headings carried handwritten ordinals (e.g. `\section{1 Introduction}`) that stacked with LaTeX auto-numbering into "1 1 Introduction"; `\subsubsection` placed directly under `\section` produced 2.0.x off-level numbers; the appendix used a plain `\section`. All unified to pure auto-numbering — handwritten ordinals deleted, `\subsubsection` promoted to `\subsection` (auto numbers 2.1–2.5, 3.1–3.5 verified item-by-item against the in-text §2.1–§2.5, §3.1–§3.3/§3.5 references), appendix switched to the `\appendix` rule and numbered "A Number Traceability Table" (matching the in-text "Appendix A" references).
2. **Overfull elimination (8 boxes, 4.7–67.4pt)**: sources located (§2.2 long `\texttt` path chunk, §2.3 benchmark JSON names, §3.3 SHA-256 anchor run, §3.4 demarcation sentence, future-work slash list, abstract). Root cause: with long unbreakable tokens, every overflow-free line-breaking candidate exceeds the default `\tolerance=200`, so TeX falls back to overfull lines. Fix: preamble `\tolerance=9999` + `\emergencystretch` raised from 2em to 3em (the standard LaTeX relaxed-breaking settings). Measured Overfull 8→0; pixel-level four-edge page check clean.
3. **Missing font shapes**: `DejaVuSerif/m/it undefined` (the system DejaVu Serif ships no italic file; italics were silently substituted by upright) → fontspec `AutoFakeSlant=0.25` fake italic. Warnings cleared; the subtitle italic and reference-entry italics render properly.
4. **Compile warnings cleared**: the hyperref bookmark-level jump warning (triggered by a `\subsubsection` two levels below `\section`) disappears with the level promotion; no missing characters; no float overflow (Figures 1–5 all placed by [htbp]); no table of contents (this version has none — not applicable).
5. **No regression of settled compliance items**: metadata, figure renumbering (Figures 1–5 by first appearance), AI disclosure, and citation numbering [1]–[62] are all unchanged.

**Frozen-number verification**: byte-level diff review of the fixed vs first-delivery tex — every change is a layout command or a restoration of eaten characters (`τ*`, `*`, `[0,4]`); the 18 frozen anchors match item-by-item.

### 5. Round-3 fixes (2026-09-08 night: arXiv pristine-environment font compatibility + availability statements moved to footnotes)

Root-cause fixes for the reported arXiv compile failure. **Frozen numbers and verdict wording untouched** (re-verified item by item in the compiled PDF):

1. **Chinese main font, three-level fallback (the arXiv-critical fix; CN package only)**: the original `\setCJKmainfont{WenQuanYi Zen Hei}` depends on a locally installed system font that arXiv servers do not carry, so xeCJK's name lookup fails there by construction. Replaced with an `\IfFontExistsTF` chain: `FandolHei-Regular.otf` (fandol ships with TeX Live; loaded by file name through kpathsea, independent of fontconfig and system fonts — the arXiv path) → Noto Sans CJK SC (common system fallback) → WenQuanYi Zen Hei (local fallback), all with `AutoFakeBold=2.2`. The local verified build hit the fandol branch (tectonic fetched the font file from the TeX Live bundle), i.e. exactly the path arXiv will take.
2. **Latin font and symbol fallbacks (belt and braces, both packages)**: `\setmainfont{DejaVu Serif}` wrapped in `IfFontExistsTF` with a Latin Modern fallback; the ★ (U+2605) / ≫ (U+226B) DejaVu Sans mapping gained `\ensuremath{\bigstar}` / `\ensuremath{\gg}` (amssymb) fallbacks. TeX Live bundles the dejavu package, so arXiv hits the DejaVu branch.
3. **Data / Artifact availability moved to footnotes (CN/EN symmetric)**: the pre-abstract "Data availability and evidence-strength conventions" quote block became a first-page footnote (anchored on the arXiv / Repository header line, marker 1); the end-of-paper "Artifact availability" paragraph became a footnote (anchored at the end of the §3.3 pre-registration anchor sentence, marker 2); the previously orphaned closing "¹ Project version and author declaration" note became a `\thanks` starred footnote (anchored on the author name, ∗). The three statements now form one standard footnote system with no duplicate body text; the moved wording was captured byte-for-byte from the original, with no textual change.
4. **arXiv-2026 compliance re-check, zero regression**: inline thebibliography (no bibtex dependency); XeLaTeX auto-detected; metadata / abstract length / AI disclosure unchanged; figure, section, and citation numbering ([1]–[34] cited in text, [35]–[62] retained) unchanged; all 18 frozen anchors re-verified in the compiled PDF.
5. **Round-3 verified builds (tectonic 0.15.0)**: EN 0 errors / 0 Overfull / 0 missing glyphs / 24 pages; CN 0 errors / 0 Overfull / 0 missing glyphs / 17 pages.

### 6. Round-4 fixes (2026-09-08, late night continued: Data / Artifact availability and the AI declaration promoted to standalone end-of-body sections)

Per the user's instructions (15:38 "move Data availability to the end of the body (standalone section after Conclusion)"; 15:43 "promote Artifact availability to a standalone section too"; 15:48 "promote the AI declaration to a standalone section as well"). **Frozen numbers and verdict wording untouched** (re-verified in the compiled PDF):

1. **Four statements promoted to standalone body sections**: the first-page footnote 1 (Data availability and evidence-strength conventions) became a `\section*` "Data availability and evidence-strength conventions"; the §3.3 footnote 2 became a `\section*` "Artifact availability"; the `\thanks` starred title-page footnote (Project version and author declaration, containing the AI-assistance and responsibility declaration) became a `\section*` "Project version and author declaration"; its embedded "Acknowledgments" paragraph became a `\section*` "Acknowledgments". All four sit after the Conclusion and before the appendix (A Number Traceability Table) — the standard journal back-matter position.
2. **Wording moved byte-for-byte**; the complete diff vs the round-3 tex has exactly 5 hunks: (i) removed the now purposeless footnote-counter setup (comment and line); (ii) footnote 1 removed from the first-page Repository header line; (iii) footnote 2 removed from the §3.3 pre-registration anchor sentence; (iv) `\thanks` removed from the author line (name and affiliation unchanged); (v) four `\section*` sections inserted after the Conclusion. The only character-level text changes in either language version are two sentence-initial capitalizations in this English package ("all"→"All", "the"→"The"); the Chinese package has zero character-level text changes.
3. **Title-page form**: the title page now carries no footnote marks at all (the former ∗/1/2 system moved up into body sections); the arXiv/Repository header line and the §3.3 sentence are back to footnote-free form.
4. **arXiv compliance note**: arXiv imposes no requirement or position rule for Data/Artifact availability or AI declarations; standalone end-of-body sections are the standard journal style and fully compliant; the three elements of the AI-use disclosure (version, scope of AI assistance, full author responsibility) are preserved verbatim; the repository link remains visible on the first-page header line.
5. **Round-4 verified builds (tectonic 0.15.0)**: EN 0 errors / 0 Overfull / 0 missing glyphs / 24 pages; CN 0 errors / 0 Overfull / 0 missing glyphs / 18 pages (round 3 was 17; the added sections push the flow by one page). Sixteen frozen anchors (full residual 2.220446049250313, P1a 0.8569, ECR 1.333, GSM8K 0.87/0.899/85.0/97.0, seed 210021, GT-5b 22/22, GT-6 1.594e-29, 6760 states, five pre-registered SHA-256 first-12-hex anchors) re-verified item-by-item in both compiled PDFs.

## Author and AI disclosure (per arXiv 2026 policy)

- **Author**: Qihao Yuan (corresponding), School of Chemistry and Life Resources, Renmin University of China (research assistant).
- **AI assistance**: The Deposon framework and project guidance were provided by the corresponding author. The core algorithm, the experimental pipeline, and the first draft of this manuscript were produced with the assistance of KIMI (Moonshot AI). The author reviewed, edited, and takes full responsibility for all content under arXiv's authorship and AI-use policy.
- **License**: to be selected by the author in the arXiv submission form (recommendation: CC BY 4.0 or the default arXiv license). No license is asserted inside the manuscript.
- **Funding / COI**: no funding statement is included (none provided by the author); add before submission if applicable.

## Citation numbering

References are numbered in the order of first appearance, per arXiv standard: entries [1]–[34] are cited in the text; entries [35]–[62] are retained for completeness of the unified external reference system and are not cited in the body. Verification annotations: `docs/REF_VERIFICATION_v2.md` in the repository.
