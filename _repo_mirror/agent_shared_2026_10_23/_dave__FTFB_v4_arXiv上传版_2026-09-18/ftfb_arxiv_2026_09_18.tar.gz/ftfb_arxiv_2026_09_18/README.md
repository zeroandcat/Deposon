# Fiction That Feeds Back: From Non-Euclidean Geometry to Machine Worldviews

arXiv submission package (2026-09-18). Single-author preprint.

## Contents

- `fiction_that_feeds_back.tex` — typeset source (pdflatex-compatible; no system-font
  or fontspec dependencies; standard packages only: fontenc, inputenc, lmodern, pifont,
  newunicodechar, amsmath/amssymb, graphicx, booktabs, tabularx, hyperref, url,
  enumitem, geometry).
- `compile_verification.txt` — neutralized compile verification record (quality-gate
  facts only: four-zero metrics, visual gate, structural checks, submission-edition
  hygiene scan, deliverable fingerprints).

## Build

    pdflatex fiction_that_feeds_back.tex   (run 3 times)

Expected: 24 pages, A4; zero compile errors, zero overfull boxes, zero missing
characters, zero undefined references. The reference list is a closed pool of 56
numbered entries ([R01]-[R56]); pool numbers are by design (see §1.3 of the paper).
Entry [R56] is an author-anonymized companion-study placeholder (double-blind
review convention; to be restored at camera-ready).

## Notes for the submitter

- Submission info line (page 1, under the title block): arXiv subjects
  cs.AI (primary) · physics.hist-ph · cs.CY; License CC BY 4.0; Conflicts of
  interest: none declared; Date 2026-09-18.
- Suggested arXiv metadata abstract must be taken verbatim from the paper's
  Abstract section; note it currently exceeds the 1920-character metadata limit
  (see the submission metadata sheet accompanying this package outside the tarball).
