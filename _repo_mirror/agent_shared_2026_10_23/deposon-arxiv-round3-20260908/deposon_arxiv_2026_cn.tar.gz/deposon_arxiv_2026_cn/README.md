# Deposon 论文 — arXiv 源码包（中文版，修复更新版）

**项目版本**：deposon v0.1.1 · **日期**：2026-09-08
**arXiv 类目**：cs.AI
**代码仓库**：https://github.com/zeroandcat/Deposon
**作者**：袁祺皓（单一作者），〔高校R〕化学与生命资源学院

本包为**纯中文版**源码包，由 2026-09-08 交付的混合包拆分而来；本包为同日**修复更新版（第三轮）**：首发拆分包 README 所列「已知遗留问题」9 类及后续编译实测显形的排版可见性问题已全部修复；第二轮追加修复标题双重编号、Overfull 越界与字体缺失类问题，tectonic 实测 0 error / 0 Overfull 编译闭环（见下方修复记录）。第三轮追加：arXiv 服务器纯净 TeX 环境字体兼容（fandol 文件名直载三级回退链）与 Data / Artifact availability 声明脚注化，冻结数字与判定口径零改动。原混合包与首发拆分包均保留备查。另有同结构的纯英文包 `deposon_arxiv_2026_en.tar.gz`（同为第二轮修复更新版）。

## 包内清单

- `deposon_paper_cn.tex` — 中文版论文（已修复）
- `references.bib` — BibTeX 文献库（62 条）。tex 使用内联 `thebibliography` 编译，无需 BibTeX；`.bib` 供下游复用。
- `figures/` — 5 张中文图（按正文首现顺序编号，图1–图5）：`fig1_ecr_distribution_cn.png`、`fig2_boundary_map_cn.png`、`fig3_killsign_scatter_cn.png`、`fig4_division_scatter_cn.png`、`fig5_gt7_frontier_cn.png`。图内数据与冻结 JSON 一字未动；文件名跟随重排后的图号。
- 包内不含编译产物（PDF 不打入包内，随群消息另行附上编译验证 PDF）。

## 编译方式（中文版）：XeLaTeX + xeCJK

本版本必须使用 **XeLaTeX**（pdflatex 不适用）：

```bash
xelatex deposon_paper_cn.tex
xelatex deposon_paper_cn.tex   # 交叉引用需运行两遍
# 或（本次实测命令，tectonic 0.15.0 联网拉包）：
tectonic deposon_paper_cn.tex
```

- 导言区已预置**三级字体回退链，无需本机安装任何系统字体**：中文主字体 `FandolHei-Regular.otf`（fandol，TeX Live 自带；`\IfFontExistsTF` 文件名直载）→ Noto Sans CJK SC → WenQuanYi Zen Hei，均带 `AutoFakeBold=2.2` 伪粗体；西文 `DejaVu Serif`（TeX Live 自带，缺失时回退 Latin Modern，带 `AutoFakeSlant=0.25`）；★/≫ 用 DejaVu Sans（缺失时回退 `\bigstar`/`\gg`）。
- **arXiv 服务器兼容（第三轮核心）**：上述字体全部在 TeX Live 发行版内（fandol / dejavu / lmodern / amsfonts），arXiv 纯净 TeX 环境可直接解析，不依赖任何本机系统字体；arXiv 构建系统依 fontspec/xeCJK 依赖特征自动选择 XeLaTeX 引擎，无需手工指定。
- **实测结果（2026-09-08 第三轮，字体链升级后复测）**：tectonic 0 error / 0 Overfull 编译通过，17 页 PDF（pdfinfo 口径；旧记录「18 页」为 pdftotext 计页口径含尾随换页符）；0 缺字形警告；编译日志确认 FandolHei-Regular.otf + DejaVu Serif + DejaVu Sans 全部就位（fandol 分支命中，与 arXiv 解析路径一致）。

## 修复记录（2026-09-08：首发包遗留问题已全部修复并实测闭环）

修复原则：**冻结数字与判定口径零改动**。除恢复被转换层吞掉的 `τ*`、字段通配符 `*` 与区间 `[0,4]` 外，无任何文字内容变动；排版类修复仅增删排版指令，不增删可见字符。18 项冻结数字锚点（审计残差 2.220446049250313、P1a max‖T−BR‖∞=0.8569、ECR median=1.333、GSM8K 85.0/CoT 97.0、seed=210021、五个预登记 SHA-256 前 12 位等）修复前后逐项计数一致。

**共 13 类 30 处修复**：首发 README 清单 9 类 15 处 + 字形渲染 1 类 + 编译实测后追加的排版可见性修复 3 类 14 处。

### 一、首发 README「已知遗留问题」清单逐条修复（9 类 15 处，行号为首发包行号）

1. **L6 标题双换行（已修复）**：删去 `\\[2mm]` 后多余的 ` \\ `，消除 `\maketitle` 时 "There's no line here to end" 硬错误（原样 tex 的实测首个中断点）。
2. **导言区宏包块（已修复）**：补入 amsmath,amssymb / graphicx / booktabs / longtable / hyperref / url / enumitem / geometry 与 `\graphicspath{{figures/}}`（与英文版导言一致）。
3. **区间误转引用（3 处，已修复）**：`τ∈\cite{key00,key04}` 还原为 `τ∈[0,4]`（L111 / L168 / L220）。
4. **τ* 被吞（2 处，已修复）**：还原 `τ*`，删除误转的 `\textit{ }` 跨度。
5. **附录表格竖线误转（1 处，已修复）**：`Wilcoxon p=0.0031，|r|=0.83；配对 t p<0.0001/d=2.05` 合并为单单元格，消除 Extra alignment tab 硬错误。
6. **字段通配符被吞（2 处，已修复）**：还原 `per_T.*.per_domain.*.accuracy`、`per_domain.*.named_summary`、`backend.*` 中的 `*`。
7. **图注双转义（2 处，已修复）**：`n\_pos`、`hub\_concentration` 等改为单个 `\_`，消除 Missing $ inserted 硬错误。
8. **abstract 结构（1 处，已修复）**：`\end{abstract}` 移至关键词行之后，正文恢复正常排版。
9. **文末裸 `\footnote` 与孤立 `---`（2 处，已修复）**：删除竖直模式下无法挂载的裸 `\footnote`（与文末「¹ 项目版本与作者声明」段内容重复）及孤立分隔线。

### 二、字形渲染修复（1 类）

导言区加入 `newunicodechar` 映射：★（U+2605）与 ≫（U+226B）改由 DejaVu Sans 渲染（DejaVu Serif 未收录，首发编译中渲染为空）。正文与图注文字零改动；实测缺字形警告 0 处，★/≫ 与图内符号一致呈现。

### 三、编译实测后追加的排版可见性修复（3 类 14 处）

完整编译通过后显形（原样 tex 在 L6 即中断，无法提前观测），逐页字符坐标实测（pdfplumber）证实两类内容被裁出页面右缘：

1. **附录数字锚点表整列越缘（1 处）**：原 `tabular{ll}` 过宽（第二列字段路径整列越出页缘，实测 2697 字符不可见）。已改为 `\footnotesize` + `longtable{p{0.50\textwidth}p{0.42\textwidth}}`，表头经 `\endhead` 跨页重复；表格单元格内容一字未动。
2. **全局断行参数（1 处）**：导言区加入 `\emergencystretch=2em`（LaTeX 标准第三通道断行，解决长路径 `\texttt` 令 TeX 在默认 tolerance 下宁选 Overfull 的已知行为）。
3. **长 token 断点（12+1 处）**：表内 12 个 ≥40 字符长字段路径 token 与正文 1 处长串（`deposon_benchmark_v1_3_traps.json → variant_results.{…}`，xeCJK 下 `→` 两侧空格不可断）在 `.`、`,`、`→`、`_` 等自然边界插入 `\allowbreak`（纯断点许可，零可见字符增删）。修复前正文 33 字符越缘，修复后 0。

**修复后残留**：首轮残留 Overfull 4 处已于第二轮清零（见下节四）；Underfull 82 处为放宽断行容忍度后的页内松紧提示，内容完整无缺；无缺字形；无越缘字符。

**冻结核验**：修复前后 tex 逐字节 diff 复核——所有变更仅为排版指令与被吞字符（`τ*`、`*`、`[0,4]`）的恢复；18 项冻结锚点逐项计数一致。

### 四、第二轮修复（2026-09-08 晚：编号统一 + Overfull 清零 + 字体补全，用户反馈复检）

依据用户对编译验证 PDF 的反馈（标题双重编号、部分字段超出页面）追加修复，并全面复检。**正文文字、数字与判定口径零改动**（diff 复核：变更仅涉标题命令与导言区 4 行排版参数）：

1. **标题双重编号（16 处标题命令）**：原 tex 标题自带手写序号（如 `\section{1 引言}`），与 LaTeX 自动编号叠加成「1 1 引言」；且 `\section` 下直接套 `\subsubsection` 产生 2.0.x 错层编号；附录用普通 `\section`。已统一改为纯自动编号——删除全部手写序号，`\subsubsection` 理顺为 `\subsection`（自动编号 2.1–2.5、3.1–3.5 与正文手写引用 §2.1–§2.5、§3.1–§3.5 逐项核验一致），附录改走 `\appendix` 规则编为「A 数字追溯表」（正文「附录 A」引用一致）。
2. **Overfull 越界清零（4 处，12.5/22.6/6.4/21.0pt）**：定位具体源（§2.2 长 \texttt 路径串、§3.2 GT-4 段 ECR 定义、§3.3 P1a 数学串、§3.3 预登记 SHA-256 锚段）。根因：长不可断 token 令 TeX 在默认 `\tolerance=200` 下所有无溢出断行方案 badness 均超限，被迫输出溢出行。修复：导言区 `\tolerance=9999` + `\emergencystretch` 由 2em 增至 3em（LaTeX 标准宽松断行参数），编译实测 Overfull 4→0，页面像素级四边复检干净。
3. **字体缺失类（2 类）**：`DejaVuSerif/m/it undefined`（系统 DejaVu Serif 无斜体文件，斜体静默替换为正体）→ fontspec `AutoFakeSlant=0.25` 伪斜体；`WenQuanYiZenHei/b/n undefined`（文泉驿无粗体，中文粗体静默失效）→ xeCJK `AutoFakeBold=2.2` 伪粗体。两处警告清零，标题英文副题斜体与正文粗体判定名恢复应有字形。
4. **编译警告清零**：hyperref bookmark 层级跳差警告（`\section` 直下 `\subsubsection` 跳 2 级触发）随层级理顺自动消失；无 missing character、无 float 越界（图 1–5 均 [htbp] 正常浮动）、无目录（本版无 `\tableofcontents`，不适用）。
5. **既定合规项零回退**：元数据、图表重排编号（图 1–5 按正文首现顺序）、AI 披露、引用编号 [1]–[62] 均保持不变。

### 五、第三轮修复（2026-09-08 深夜：arXiv 服务器纯净环境兼容 + 可用性声明脚注化）

针对 arXiv 上传编译失败的根因修复。**冻结数字与判定口径零改动**（编译后 PDF 逐项复检）：

1. **中文主字体三级回退链（arXiv 必要修复）**：原 `\setCJKmainfont{WenQuanYi Zen Hei}` 依赖本机系统字体，arXiv 服务器不内置该字体、xeCJK 名称查找必然失败。改为 `\IfFontExistsTF` 三级链：`FandolHei-Regular.otf`（fandol，TeX Live 自带，文件名直载经 kpathsea 解析，不依赖 fontconfig 与系统字体——arXiv 环境首选）→ Noto Sans CJK SC（常见系统回退）→ WenQuanYi Zen Hei（本机回退），三级均带 `AutoFakeBold=2.2`。本地实测命中 fandol 分支（tectonic 自 TeX Live bundle 拉取字体文件成功），即 arXiv 服务器同一路径。
2. **西文字体与符号回退（双保险）**：`\setmainfont{DejaVu Serif}` 包裹 `IfFontExistsTF`，缺失时回退 Latin Modern；★（U+2605）/≫（U+226B）的 DejaVu Sans 映射加回退 `\ensuremath{\bigstar}` / `\ensuremath{\gg}`（amssymb）。TeX Live 自带 dejavu 包，arXiv 正常命中 DejaVu 分支。
3. **Data / Artifact availability 脚注化（中英一致）**：摘要前「数据可用性与证据强度约定」引用块 → 首页脚注（锚于 arXiv / Repository 头行，编号 1）；文末「Artifact availability」段 → 脚注（锚于 §3.3 预登记锚点句末，编号 2）；原孤立「¹ 项目版本与作者声明」文末注 → `\thanks` 星标脚注（锚于作者名，∗）。三条声明统一为标准脚注体系、正文无重复残留；脚注文字逐字节取自原文搬移，无任何文字改动。
4. **arXiv 2026 合规复核零回退**：thebibliography 内联（无 bibtex 依赖）；XeLaTeX 引擎自动识别；元数据 / 摘要长度 / AI 披露内容不变；图表编号、章节自动编号、引用编号 [1]–[34]（正文）/ [35]–[62]（完整性保留）不变；18 项冻结锚点逐项在编译后 PDF 检出。
5. **第三轮实测**：tectonic 0.15.0——CN 0 error / 0 Overfull / 0 缺字形 / 17 页；EN 0 error / 0 Overfull / 0 缺字形 / 24 页。

## 作者与 AI 披露（arXiv 2026 政策）

- **作者**：袁祺皓（通讯作者），〔高校R〕化学与生命资源学院，科研助理。
- **AI 协助**：Deposon 框架定义与项目指导由通讯作者提供；核心算法、实验管线与论文初稿由 KIMI（Moonshot AI，月之暗面）协助完成；作者已审阅、编辑，并按 arXiv 著作权与 AI 使用政策对全部内容承担完全责任。
- **许可**：投稿时在 arXiv 表单选择（建议 CC BY 4.0 或 arXiv 默认许可）；正文内不断言任何许可。
- **资助 / 利益冲突**：无资助声明（作者未提供）；如投稿前情况变化再补充。

## 引用编号

参考文献按正文首次出现顺序编号（arXiv 标准）：[1]–[34] 在正文中被引用；[35]–[62] 为统一外部文献体系完整性保留，正文未引用。核验标注见仓库 `docs/REF_VERIFICATION_v2.md`。
