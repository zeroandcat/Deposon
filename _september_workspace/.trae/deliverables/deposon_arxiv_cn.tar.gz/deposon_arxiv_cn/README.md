# Deposon（凝子）— arXiv 投稿包（中文版）

本包包含论文的中文版：

**Deposon：可审计、守恒保证、经博弈论检验的 LLM 推理路径散射层**

## 内容

- `deposon_paper_cn.tex` — LaTeX 源文件（pdfLaTeX，`article` 文档类）
- `references.bib` — BibTeX 参考文献（34 条）。`.tex` 文件内已内嵌
  `thebibliography` 环境，**编译无需运行 BibTeX**。
- `figures/` — 5 张中文标注图片（PNG）
- `README.md` — 本文件

## 编译方法

```
pdflatex deposon_paper_cn.tex
pdflatex deposon_paper_cn.tex
```

需运行 **两遍** pdfLaTeX 以解析交叉引用。中文版使用 `CJKutf8` 宏包与
`gbsn`（简体中文宋体）字体；使用 MiKTeX 时首次编译会自动下载安装所需
字体宏包（需联网），TeX Live 用户请确认已安装 CJK 相关宏包。

## AI 使用披露

项目版本：deposon v2（2026-09-08）。Deposon 框架定义与项目指导由通讯
作者提供；核心算法、实验管线与论文初稿由 KIMI（月之暗面 Moonshot AI）
协助完成，作者已审阅、修订全文，并依 arXiv 著作权与 AI 使用政策对全部
内容承担完全责任。

## 许可

CC BY 4.0 — https://creativecommons.org/licenses/by/4.0/

## 引用编号说明

全部 34 条参考文献（[1]–[34]）均在正文中被引用，内嵌的参考文献表仅含这 34 条。
