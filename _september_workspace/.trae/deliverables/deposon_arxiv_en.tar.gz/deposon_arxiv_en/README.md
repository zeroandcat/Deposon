# Deposon — arXiv submission package (English)

This package contains the English version of the paper:

**Deposon: An Auditable, Conservation-Guaranteed, Game-Theoretically Tested
Scattering Layer over LLM Reasoning Paths**

## Contents

- `deposon_paper_en.tex` — LaTeX source (pdfLaTeX, `article` class)
- `references.bib` — BibTeX references (34 entries). The `.tex` file also
  embeds a `thebibliography` environment, so **no BibTeX run is required** to
  compile.
- `figures/` — 5 figures with English labels (PNG)
- `README.md` — this file

## Compilation

```
pdflatex deposon_paper_en.tex
pdflatex deposon_paper_en.tex
```

Run pdfLaTeX **twice** to resolve cross-references. Standard packages are used
(`graphicx`, `booktabs`, `longtable`, `amsmath`, `hyperref`, `geometry`).

## AI-use disclosure

Project version: deposon v2 (2026-09-08). The Deposon framework definition
and project guidance were provided by the corresponding author. The core
algorithm, the experimental pipeline, and the first draft of the manuscript
were produced with the assistance of KIMI (Moonshot AI); the author reviewed
and edited the manuscript and takes full responsibility for all content under
arXiv's authorship and AI-use policy.

## License

CC BY 4.0 — https://creativecommons.org/licenses/by/4.0/

## Reference numbering

All 34 references ([1]–[34]) are cited in the main text, and the embedded
bibliography contains exactly these 34 entries.
